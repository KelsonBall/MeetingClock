#MeetingClock

Provides a visual display of the cost incurred during meetings. 

## Usage
 1. Enter a valid hourly rate in the "Average Hourly Rate" field.
 2. Enter the number of participants.
 3. Enter an Alert Interval value.   
   * The computer will beep every time the value specified in the alert interval has been spent.
 4. Toggle the clock state to 'Run.'